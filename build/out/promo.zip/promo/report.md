# Imagerie promotionnelle : rapport

Généré par `node build/promo.js` (voir plus bas). Sorties dans `build/out/promo/` (ignorées par git).

## Commande unique pour tout régénérer

```bash
PW_CHROMIUM=/chemin/vers/chromium node build/promo.js
```

Étapes seules : `node build/promo.js shots|clips|social|check`. Prérequis : Playwright, ffmpeg (libx264), python3 + Pillow + numpy. `build/promo-check.py` fait les contrôles, la planche et ce rapport.

## Fichiers (dimensions, poids)

| Fichier | Dimensions | Poids | Détail |
|---|---|---|---|
| `ch1/en/clocher.png` | 1920x1080 | 879 Ko | PNG |
| `ch1/en/fonderie-colosse.png` | 1920x1080 | 925 Ko | PNG |
| `ch1/en/menu.png` | 1920x1080 | 336 Ko | PNG |
| `ch1/en/pont.png` | 1920x1080 | 787 Ko | PNG |
| `ch1/fr/clocher.png` | 1920x1080 | 879 Ko | PNG |
| `ch1/fr/fonderie-colosse.png` | 1920x1080 | 925 Ko | PNG |
| `ch1/fr/menu.png` | 1920x1080 | 337 Ko | PNG |
| `ch1/fr/pont.png` | 1920x1080 | 787 Ko | PNG |
| `ch2/clips/clip-blocage.mp4` | 1920x1080 | 2616 Ko | h264, 30/1 i/s, 7.0 s |
| `ch2/clips/clip-pas-de-cote.mp4` | 1920x1080 | 2117 Ko | h264, 30/1 i/s, 7.0 s |
| `ch2/clips/clip-riposte.mp4` | 1920x1080 | 2618 Ko | h264, 30/1 i/s, 7.0 s |
| `ch2/en/intro-phare.png` | 1920x1080 | 721 Ko | PNG |
| `ch2/en/menu.png` | 1920x1080 | 382 Ko | PNG |
| `ch2/en/p1-reflets.png` | 1920x1080 | 1099 Ko | PNG |
| `ch2/en/p2-cale-blocage.png` | 1920x1080 | 914 Ko | PNG |
| `ch2/en/p3-phare-forme1.png` | 1920x1080 | 1060 Ko | PNG |
| `ch2/en/riposte.png` | 1920x1080 | 1096 Ko | PNG |
| `ch2/fr/intro-phare.png` | 1920x1080 | 721 Ko | PNG |
| `ch2/fr/menu.png` | 1920x1080 | 381 Ko | PNG |
| `ch2/fr/p1-reflets.png` | 1920x1080 | 1099 Ko | PNG |
| `ch2/fr/p2-cale-blocage.png` | 1920x1080 | 914 Ko | PNG |
| `ch2/fr/p3-phare-forme1.png` | 1920x1080 | 1060 Ko | PNG |
| `ch2/fr/riposte.png` | 1920x1080 | 1096 Ko | PNG |
| `hub/en/hub-couronne.png` | 1920x1080 | 401 Ko | PNG |
| `hub/fr/hub-couronne.png` | 1920x1080 | 401 Ko | PNG |
| `social/banner.png` | 1920x640 | 558 Ko | PNG |
| `social/cover.gif` | 630x500 | 2790 Ko | 90 images, 4.5 s |
| `social/cover.png` | 630x500 | 136 Ko | PNG |
| `social/og-1200x630.png` | 1200x630 | 486 Ko | PNG |
| `social/post-1080x1080.png` | 1080x1080 | 601 Ko | PNG |
| `social/post-1600x900.png` | 1600x900 | 900 Ko | PNG |
| `ch2/clips/clip-blocage.gif` | 640x360 | 2813 Ko | 105 images, 7.0 s |
| `ch2/clips/clip-pas-de-cote.gif` | 640x360 | 2720 Ko | 105 images, 7.0 s |
| `ch2/clips/clip-riposte.gif` | 544x306 | 2211 Ko | 105 images, 7.0 s |

`contact-sheet.png` : planche de toutes les images, étiquetées par nom de fichier (à la racine, hors des dossiers de livraison).

## Instants du jeu choisis

| Fichier | Contenu | Phase interne | Forme | PV Veilleur | PV boss | Temps de jeu (s) |
|---|---|---|---|---|---|---|
| `ch2/fr/menu.png` | menu |  |  |  |  |  |
| `ch2/fr/intro-phare.png` | prologue |  |  |  |  | 10 |
| `ch2/fr/p1-reflets.png` | play | 2 | 1 | 4/4 | 4/10 | 26.587 |
| `ch2/fr/p2-cale-blocage.png` | play | 1 | 1 | 4/4 | 8/10 | 16.03 |
| `ch2/fr/p3-phare-forme1.png` | play | 3 | 1 | 4/4 | 10/10 | 15.95 |
| `ch2/fr/riposte.png` | play | 3 | 1 | 4/4 | 8/10 | 17.673 |
| `hub/fr/hub-couronne.png` | hub |  |  |  |  |  |
| `ch1/fr/menu.png` | menu |  |  |  |  |  |
| `ch1/fr/pont.png` | play | 0 |  | 4 | 9 | 11 |
| `ch1/fr/fonderie-colosse.png` | play | 1 |  | 4 | 9 | 6 |
| `ch1/fr/clocher.png` | play | 2 |  | 4 | 9 | 12 |
| `ch2/en/menu.png` | menu |  |  |  |  |  |
| `ch2/en/intro-phare.png` | prologue |  |  |  |  | 10 |
| `ch2/en/p1-reflets.png` | play | 2 | 1 | 4/4 | 4/10 | 26.587 |
| `ch2/en/p2-cale-blocage.png` | play | 1 | 1 | 4/4 | 8/10 | 16.03 |
| `ch2/en/p3-phare-forme1.png` | play | 3 | 1 | 4/4 | 10/10 | 15.95 |
| `ch2/en/riposte.png` | play | 3 | 1 | 4/4 | 8/10 | 17.673 |
| `hub/en/hub-couronne.png` | hub |  |  |  |  |  |
| `ch1/en/menu.png` | menu |  |  |  |  |  |
| `ch1/en/pont.png` | play | 0 |  | 4 | 9 | 11 |
| `ch1/en/fonderie-colosse.png` | play | 1 |  | 4 | 9 | 6 |
| `ch1/en/clocher.png` | play | 2 |  | 4 | 9 | 12 |
| `clip-blocage` | play | 1 | 1 | 4/4 | 8/10 | 9.367 |
| `clip-pas-de-cote` | play | 2 | 1 | 4/4 | 8/10 | 6.467 |
| `clip-riposte` | play | 3 | 1 | 4/4 | 8/10 | 14.2 |
| `cover-src` | play | 1 | 1 | 4/4 | 4/10 | 18.203 |

Numéros internes : phase 2 = Phase I (La Voix Creuse), 1 = Phase II (L'Ancien de Rouille), 3 = Phase III (Le Phare Noyé). Chapitre I : `ph` 1 pont, 2 Fonderie, 3 Clocher ; `secs` = secondes de jeu depuis le début de la phase. Intro : t = 10 s (plan du Phare au large). Clips : `gtStart` à `gtEnd`.

## Méthode

- Jeu avancé pas à pas (1/60 s) dans les copies de test à crochets (`build/out/ch2-test.html`, `build/out/test.html`), graine fixe, horloge manuelle ; bot parfait (appui 50 ms avant l'impact) : aucun coup reçu, PV pleins, Normal, aide visuelle désactivée.
- Captures de scène : l'élément `#stage` (960 × 540 px CSS, bordure masquée à la capture), facteur d'échelle 2 → 1920 × 1080 natifs (le canvas est rendu à cette taille, aucun agrandissement). Menu, hub : fenêtre 960 × 540, facteur 2. Intro : bitmap 1920 × 1080 du canvas de la cinématique (sans légende ni bouton « Passer »).
- Cover : recadrage 680 × 540 px CSS (1360 × 1080) → 630 × 500, 20 i/s, fondu enchaîné de 0,5 s pour la boucle.

## Contrôles automatiques

- Dimensions exactes, GIF < 3 Mo, métadonnées absentes, MP4 H.264 30 i/s sans son : OK
- Boucle du GIF : ecart moyen entre images voisines 5.56 ; ecart derniere -> premiere 3.79 (rapport 0.68)
- Écrans exclus : aucun texte exclu dessiné, phase III en forme I seulement, mode « play » à chaque image des clips, aucun coup reçu, aucune carte de défaite : OK

### Réglages des GIF (échelle de repli)

- clip-blocage.gif : 640x360 128 couleurs 15 i/s -> 3.10 Mo
- clip-blocage.gif : 640x360 96 couleurs 15 i/s -> 2.88 Mo
- clip-pas-de-cote.gif : 640x360 128 couleurs 15 i/s -> 2.96 Mo
- clip-pas-de-cote.gif : 640x360 96 couleurs 15 i/s -> 2.79 Mo
- clip-riposte.gif : 640x360 128 couleurs 15 i/s -> 3.79 Mo
- clip-riposte.gif : 640x360 96 couleurs 15 i/s -> 3.48 Mo
- clip-riposte.gif : 640x360 64 couleurs 15 i/s -> 3.00 Mo
- clip-riposte.gif : 544x306 64 couleurs 15 i/s -> 2.26 Mo
- cover.gif : 630x500 96 couleurs 20 i/s 5.5 s -> 4.39 Mo
- cover.gif : 630x500 64 couleurs 20 i/s 5.5 s -> 3.84 Mo
- cover.gif : 630x500 48 couleurs 20 i/s 5.5 s -> 3.54 Mo
- cover.gif : 630x500 96 couleurs 20 i/s 5 s -> 3.72 Mo
- cover.gif : 630x500 64 couleurs 20 i/s 5 s -> 3.36 Mo
- cover.gif : 630x500 48 couleurs 20 i/s 5 s -> 3.12 Mo
- cover.gif : 630x500 96 couleurs 20 i/s 4.5 s -> 3.47 Mo
- cover.gif : 630x500 64 couleurs 20 i/s 4.5 s -> 3.17 Mo
- cover.gif : 630x500 48 couleurs 20 i/s 4.5 s -> 2.86 Mo

## Points douteux et écarts de méthode

- **Fenêtre** : la consigne donne un viewport 960 × 540. À cette taille la page de jeu est trop haute (en-tête, scène réduite à 926 × 520 px CSS, défilement) : la scène ferait 1852 × 1040 et il faudrait l'agrandir. Les captures de scène sont donc faites dans une fenêtre plus grande (1280 × 1000) en prenant `#stage` à 960 × 540 ; menu, hub et intro suivent la consigne (960 × 540). Les barres de PV (HTML, hors canvas) n'apparaissent pas : à valider.
- Les captures de scène ne montrent aucun texte HTML ; seules les onomatopées du jeu (CLANG) sont dessinées. Le menu et le hub affichent le numéro de version « v1.0.0 » (texte du jeu) ; le hub utilise un « LUMEN » jaune (couleur de la marque du hub, pas d'un chapitre).
- Le « Phare au large » (intro) est un plan sans texte ; l'intro complète n'est pas dans une exclusion, mais le plan du titre n'est pas utilisé.
- Boucle du GIF : fondu enchaîné de 0,5 s (le combat n'est pas périodique) ; le Veilleur et le boss sont brièvement en double sur ces 10 images.
- Clips : en anglais (les seuls textes sont des onomatopées, identiques en français). GIF de clips à 640 × 360 et 15 i/s pour tenir sous 3 Mo ; MP4 en 1080p 30 i/s.
- Banner : 1920 × 640 (3:1), limité par la largeur de la source (1920) ; dimensions finales à confirmer.
- Les photos sociales sont tirées des captures anglaises (sans texte ajouté).
- Les fichiers d'outil `build/promo.js` et `build/promo-check.py` sont nouveaux ; aucun fichier source du jeu ni dist n'est modifié.
